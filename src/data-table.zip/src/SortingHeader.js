import React from 'react';
import { TableRow, TableCell, TableSortLabel, Tooltip, IconButton } from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';
import PropTypes from 'prop-types';

const SortingHeader = ({ headers, orderBy, order, handleRequestSort, tooltipFields, columnWidths }) => (
  <TableRow>
    {headers.map((header, index) => (
      <TableCell key={index} style={{ width: columnWidths[header.field] }}>
        <TableSortLabel
          active={orderBy === header.field}
          direction={orderBy === header.field ? order : 'asc'}
          onClick={() => handleRequestSort(header.field)}
        >
          <strong>{header.label}</strong>
        </TableSortLabel>
        {tooltipFields[header.field] && (
          <Tooltip
            title={
              <div>
                <ul style={{ margin: 0, paddingLeft: '20px' }}>
                  {tooltipFields[header.field].map((item, idx) => (
                    <li key={idx}>{item}</li>
                  ))}
                </ul>
              </div>
            }
            arrow
          >
            <IconButton size="small">
              <InfoIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        )}
      </TableCell>
    ))}
  </TableRow>
);

SortingHeader.propTypes = {
  headers: PropTypes.arrayOf(PropTypes.shape({
    label: PropTypes.string.isRequired,
    field: PropTypes.string.isRequired,
  })).isRequired,
  orderBy: PropTypes.string.isRequired,
  order: PropTypes.string.isRequired,
  handleRequestSort: PropTypes.func.isRequired,
  tooltipFields: PropTypes.objectOf(PropTypes.arrayOf(PropTypes.string)),
  columnWidths: PropTypes.object.isRequired,
};

export default SortingHeader;