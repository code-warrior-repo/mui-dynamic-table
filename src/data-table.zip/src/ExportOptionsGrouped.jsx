// ExportOptionsGrouped.js
import React, { useCallback, useMemo, useState } from "react";
import {
    IconButton,
    Menu,
    MenuItem,
    ListItemIcon,
    ListItemText,
    Snackbar,
    Alert,
    Tooltip,
} from "@mui/material";

import FileDownloadIcon from "@mui/icons-material/FileDownload";
import CsvIcon from "@mui/icons-material/Description";
import XlsxIcon from "@mui/icons-material/GridOn";
import PdfIcon from "@mui/icons-material/PictureAsPdf";

import PropTypes from "prop-types";
import jsPDF from "jspdf";
import { autoTable } from "jspdf-autotable";
import dayjs from "dayjs";

import { getByPath, toDisplayString } from "../src/util";

/* ------------------------------------------------------------------------ */
/* Helpers */
/* ------------------------------------------------------------------------ */

const timestamp = () => dayjs().format("MMDDYYYYHHmmssSSS");

const shortTitle = (title) => {
    if (!title) return "export";
    const parts = title.trim().split(/\s+/);
    return parts.slice(0, 2).join("_").replace(/\W+/g, "_");
};

/* Flatten accessor generation */
const buildAccessors = (headers) =>
    (headers || []).map((h) => {
        const key = h.key || h.field;
        const label = h.label || key;

        if (!key) return { key: "", label, getValue: () => "" };

        if (h.fields?.length > 0) {
            return {
                key,
                label,
                getValue: (row) => {
                    const parts = h.fields.map((p) =>
                        toDisplayString(getByPath(row, p))
                    );
                    return parts.join(h.separator || "") + (h.suffix || "");
                },
            };
        }

        const suffix = h.suffix || "";
        return {
            key,
            label,
            getValue: (row) =>
                toDisplayString(getByPath(row, h.field), h.dateFormat) + suffix,
        };
    });

/* Extracted division grouping */
function groupDivisions(rows) {
    const groups = [];
    let current = null;

    const isSpacer = (r) =>
        r.isDivisionHeaderSpacer ||
        r.isTotalSpacer ||
        r.isGrandTotalSpacer;

    rows.forEach((row) => {
        if (row.isDivisionHeader) {
            current = { division: row.division, rows: [] };
            groups.push(current);
            return;
        }
        if (isSpacer(row) || row.isColumnHeader) return;
        if (current) current.rows.push(row);
    });

    return groups;
}

/* ------------------------------------------------------------------------ */

export default function ExportOptionsGrouped({
                                                 groupedRows,
                                                 headers,
                                                 pageTitle,
                                             }) {
    const [anchorEl, setAnchorEl] = useState(null);
    const [toast, setToast] = useState({
        open: false,
        severity: "info",
        message: "",
    });

    const accessors = useMemo(() => buildAccessors(headers), [headers]);
    const filteredAccessors = useMemo(
        () => accessors.filter((a) => a.key !== "division"),
        [accessors]
    );

    const divisionGroups = useMemo(
        () => groupDivisions(groupedRows),
        [groupedRows]
    );

    const openMenu = (e) => setAnchorEl(e.currentTarget);
    const closeMenu = () => setAnchorEl(null);

    /* ------------------------------------------------------------------------ */
    /* CSV Export */
    /* ------------------------------------------------------------------------ */

    const exportCSV = useCallback(() => {
        try {
            const csvLines = [];

            const addDivision = (row) =>
                csvLines.push(`Division: ${row.division}`);
            const addHeader = () =>
                csvLines.push(accessors.map((a) => `"${a.label}"`).join(","));
            const addTotal = (row) =>
                csvLines.push(
                    ["", ...filteredAccessors.map((a) => `"${a.getValue(row) || ""}"`)].join(",")
                );
            const addData = (row) =>
                csvLines.push(
                    accessors
                        .map((a) => `"${a.getValue(row) || ""}"`)
                        .join(",")
                );

            groupedRows.forEach((row) => {
                if (row.isDivisionHeader) return addDivision(row);
                if (row.isColumnHeader) return addHeader();
                if (row.isTotal) return addTotal(row);
                return addData(row);
            });

            const blob = new Blob([csvLines.join("\n")], {
                type: "text/csv",
            });

            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = `${shortTitle(pageTitle)}_${timestamp()}.csv`;
            link.click();

            setToast({
                open: true,
                severity: "success",
                message: "CSV export complete",
            });
        } catch (err) {
            console.error(err);
            setToast({
                open: true,
                severity: "error",
                message: "CSV export failed",
            });
        }
    }, [groupedRows, accessors, filteredAccessors, pageTitle]);

    /* ------------------------------------------------------------------------ */
    /* PDF Export */
    /* ------------------------------------------------------------------------ */

    const exportPDF = useCallback(() => {
        try {
            const doc = new jsPDF();
            doc.setFontSize(16);
            doc.text(pageTitle || "", 14, 15);

            let y = 25;

            divisionGroups.forEach(({ division, rows }) => {
                const pageBottom = doc.internal.pageSize.getHeight() - 30;
                if (y > pageBottom) {
                    doc.addPage();
                    y = 20;
                }

                doc.setFontSize(13);
                doc.setFont(undefined, "bold");
                doc.text(`Division: ${division}`, 14, y);

                const head = [accessors.map((a) => a.label)];
                const body = rows.map((r) =>
                    r.isTotal
                        ? ["", ...filteredAccessors.map((a) => a.getValue(r))]
                        : accessors.map((a) => a.getValue(r))
                );

                autoTable(doc, {
                    startY: y + 6,
                    head,
                    body,
                    theme: "grid",
                    headStyles: {
                        fillColor: [52, 152, 219],
                        textColor: 255,
                        fontStyle: "bold",
                    },
                    styles: { fontSize: 9 },
                });

                y = doc.lastAutoTable.finalY + 12;
            });

            doc.save(`${shortTitle(pageTitle)}_${timestamp()}.pdf`);

            setToast({
                open: true,
                severity: "success",
                message: "PDF export complete",
            });
        } catch (err) {
            console.error(err);
            setToast({
                open: true,
                severity: "error",
                message: "PDF export failed",
            });
        }
    }, [divisionGroups, accessors, filteredAccessors, pageTitle]);

    /* ------------------------------------------------------------------------ */
    /* XLSX Export (flattened) */
    /* ------------------------------------------------------------------------ */

    const exportXLSX = useCallback(async () => {
        try {
            const [{ default: ExcelJS }, fileSaver] = await Promise.all([
                import("exceljs"),
                import("file-saver")
            ]);

            const saveAs = fileSaver.saveAs || fileSaver.default;

            const workbook = new ExcelJS.Workbook();
            const sheet = workbook.addWorksheet("Sheet1");

            // Add title row manually (no sheet.columns)
            const titleRow = sheet.addRow([pageTitle || ""]);
            const colCount = accessors.length;

            sheet.mergeCells(titleRow.number, 1, titleRow.number, colCount);
            titleRow.font = { size: 16, bold: true };

            sheet.addRow([]); // spacer

            divisionGroups.forEach(({ division, rows }) => {

                // Division header row
                const divRow = sheet.addRow([`Division: ${division}`]);
                sheet.mergeCells(divRow.number, 1, divRow.number, colCount);
                divRow.font = { size: 12, bold: true };

                // Column headers (manually added)
                const headerRow = sheet.addRow(accessors.map(a => a.label));
                headerRow.font = { bold: true };

                headerRow.eachCell(cell => {
                    cell.fill = {
                        type: "pattern",
                        pattern: "solid",
                        fgColor: { argb: "FF3498DB" }
                    };
                    cell.alignment = { horizontal: "center" };
                });

                // Data rows
                rows.forEach(r => {
                    const rowValues = r.isTotal
                        ? ["", ...filteredAccessors.map(a => a.getValue(r))]
                        : accessors.map(a => a.getValue(r));

                    const added = sheet.addRow(rowValues);
                    if (r.isTotal) added.font = { bold: true };
                });

                sheet.addRow([]); // spacer after each division
            });

            const buffer = await workbook.xlsx.writeBuffer();
            const blob = new Blob([buffer], {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            });

            saveAs(blob, `${shortTitle(pageTitle)}_${timestamp()}.xlsx`);

            setToast({
                open: true,
                severity: "success",
                message: "XLSX export complete"
            });

        } catch (err) {
            console.error(err);
            setToast({
                open: true,
                severity: "error",
                message: "XLSX export failed"
            });
        }
    }, [divisionGroups, accessors, filteredAccessors, pageTitle]);

    /* ------------------------------------------------------------------------ */
    /* Render */
    /* ------------------------------------------------------------------------ */

    return (
        <>
            <Tooltip title="Export">
                <IconButton
                    aria-label="Export"
                    data-testid="export-test-id"
                    onClick={openMenu}
                >
                    <FileDownloadIcon />
                </IconButton>
            </Tooltip>

            <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={closeMenu}>
                <MenuItem onClick={exportCSV}>
                    <ListItemIcon>
                        <CsvIcon />
                    </ListItemIcon>
                    <ListItemText primary="CSV" />
                </MenuItem>

                <MenuItem onClick={exportXLSX}>
                    <ListItemIcon>
                        <XlsxIcon />
                    </ListItemIcon>
                    <ListItemText primary="XLSX" />
                </MenuItem>

                <MenuItem onClick={exportPDF}>
                    <ListItemIcon>
                        <PdfIcon />
                    </ListItemIcon>
                    <ListItemText primary="PDF" />
                </MenuItem>
            </Menu>

            <Snackbar
                open={toast.open}
                onClose={() =>
                    setToast((t) => ({
                        ...t,
                        open: false,
                    }))
                }
            >
                <Alert severity={toast.severity}>{toast.message}</Alert>
            </Snackbar>
        </>
    );
}

ExportOptionsGrouped.propTypes = {
    groupedRows: PropTypes.array.isRequired,
    headers: PropTypes.array.isRequired,
    pageTitle: PropTypes.string,
};