import React, { useCallback, useMemo, useState } from 'react';
import {
  IconButton,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Snackbar,
  Alert,
} from '@mui/material';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import CsvIcon from '@mui/icons-material/Description';
import TxtIcon from '@mui/icons-material/TextSnippet';
import XlsxIcon from '@mui/icons-material/GridOn';
import PdfIcon from '@mui/icons-material/PictureAsPdf';
import PropTypes from 'prop-types';
import { Parser } from 'json2csv';
import jsPDF from 'jspdf';
import { autoTable } from 'jspdf-autotable';
import dayjs from 'dayjs';
import { getByPath, toDisplayString } from './util';
import Tooltip from "@mui/material/Tooltip";

/* ---------------------- Shared accessors + utils ---------------------- */

function buildHeaderAccessors(headers) {
  return headers?.map((h) => {
    const key = (h.key ?? h.field ?? '').trim();
    const label = h.label ?? key;

    if (!key) return { key: '', label, getValue: () => '' };

    if (Array.isArray(h.fields) && h.fields.length > 0) {
      const paths = h.fields.filter(Boolean);
      const sep = h.separator ?? '';
      const suffix = h.suffix ?? '';
      return {
        key,
        label,
        getValue: (row) => {
          const parts = paths.map((p) => toDisplayString(getByPath(row, p)));
          const joined = parts.join(sep);
          return suffix ? `${joined}${suffix}` : joined;
        },
      };
    }

    const path = h.field ?? '';
    const suffix = h.suffix ?? '';
    const dateFormat = h.dateFormat;
    return {
      key,
      label,
      getValue: (row) => {
        const raw = getByPath(row, path);
        const formatted = toDisplayString(raw, dateFormat);
        return suffix ? `${formatted}${suffix}` : formatted;
      },
    };
  });
}

function sanitizePlainText(text) {
  return String(text == null ? '' : text)
      .replace(/\t/g, ' ')
      .replace(/\r?\n/g, ' ');
}

function timestamp() {
  return dayjs().format('MMDDYYYYHHmmssSSS');
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 0);
}
function shortTitle(title) {
  if (!title) return "data_export";

  const parts = title.trim().split(/\s+/);   // split on space(s)

  let base = "";
  if (parts.length >= 2) {
    base = `${parts[0]}_${parts[1]}`;        // first two words
  } else {
    base = parts[0];                         // only one word
  }

  // Clean up any weird symbols, just letters/numbers/_ allowed
  return base.replace(/\W+/g, "_");
}

/* ------------------------------ Component ----------------------------- */

const ExportOptions = ({ data, headers, pageTitle, fetchAllRows, exportOptions }) => {
  const enabledFormats = {
    csv: true,
    txt: true,
    xlsx: true,
    pdf: true,
    ...exportOptions,
  };
  const [anchorEl, setAnchorEl] = useState(null);
  const [exporting, setExporting] = useState(false);
  const [toast, setToast] = useState({ open: false, severity: 'info', message: '' });

  const accessors = useMemo(() => buildHeaderAccessors(headers), [headers]);

  const openMenu = useCallback((e) => setAnchorEl(e.currentTarget), []);
  const closeMenu = useCallback(() => setAnchorEl(null), []);

  const resolveRowsForExport = useCallback(async () => {
    const usingBackend = typeof fetchAllRows === 'function';

    // Show non-blocking snackbar if we’ll call backend
    if (usingBackend) {
      setToast({
        open: true,
        severity: 'warning',
        message: 'Export started. You can continue working — the file will download when it’s ready.',
      });
    }

    setExporting(true);
    try {
      if (usingBackend) {
        const rows = await fetchAllRows();
        return Array.isArray(rows) ? rows : [];
      }
      return Array.isArray(data) ? data : [];
    } finally {
      setExporting(false);
    }
  }, [fetchAllRows, data]);

  /* ------------------------------- CSV ------------------------------- */
  const exportCSV = useCallback(async () => {
    try {
      const rows = await resolveRowsForExport();
      const fields = accessors
          .filter((a) => a.key)
          .map((a) => ({ label: a.label, value: (row) => a.getValue(row) }));

      const safeTitle = pageTitle || "";
      const fileName = shortTitle(safeTitle);
      const parser = new Parser({ fields });
      const csv = parser.parse(rows);
      downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8;' }), `${fileName}_${timestamp()}.csv`);

      setToast({ open: true, severity: 'success', message: 'CSV export completed.' });
    } catch (err) {
      console.error('Export CSV failed:', err);
      setToast({ open: true, severity: 'error', message: 'CSV export failed.' });
    }
  }, [accessors, pageTitle, resolveRowsForExport]);

  /* ------------------------------- TXT ------------------------------- */
  const exportTXT = useCallback(async () => {
    try {
      const safeTitle = pageTitle || "";
      const rows = await resolveRowsForExport();
      const headerLine = accessors.filter((a) => a.key).map((a) => sanitizePlainText(a.label)).join('\t');
      const lines = rows.map((row) =>
          accessors.filter((a) => a.key).map((a) => sanitizePlainText(a.getValue(row))).join('\t'),
      );
      const txt = [safeTitle, headerLine, ...lines].join('\n');

      const fileName = shortTitle(safeTitle);
      downloadBlob(new Blob([txt], { type: 'text/plain;charset=utf-8;' }), `${fileName}_${timestamp()}.txt`);
      setToast({ open: true, severity: 'success', message: 'TXT export completed.' });
    } catch (err) {
      console.error('Export TXT failed:', err);
      setToast({ open: true, severity: 'error', message: 'TXT export failed.' });
    }
  }, [accessors, pageTitle, resolveRowsForExport]);

  /* ------------------------------- XLSX ------------------------------ */
  const exportXLSX = useCallback(async () => {
    try {
      const rows = await resolveRowsForExport();
      const [{ default: ExcelJS }, fileSaver] = await Promise.all([
        import("exceljs"),
        import("file-saver"),
      ]);

      const saveAs = fileSaver.default || fileSaver.saveAs;

      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet("Sheet1");

      const safeTitle = pageTitle || "";


// 1. DEFINE COLUMNS — BUT DO NOT SET header: !!!
      const tableColumns = accessors
          .filter(a => a.key)
          .map(a => ({
            key: a.key,
            width: 24,
            style: { font: { size: 12 } },
          }));

      worksheet.columns = tableColumns;
      const colCount = tableColumns.length;

// 2. TITLE ROW (row 1)
      const titleRow = worksheet.addRow([safeTitle]);
      worksheet.mergeCells(1, 1, 1, colCount);
      titleRow.font = { bold: true, size: 16 };
      titleRow.alignment = { horizontal: "center" };

// 3. BLANK ROW (row 2)
      worksheet.addRow([]);

// 4. MANUAL HEADER ROW (row 3)
      const headerLabels = accessors.filter(a => a.key).map(a => a.label);
      worksheet.insertRow(3, headerLabels);

      const headerRow = worksheet.getRow(3);
      headerRow.font = { bold: true };
      headerRow.alignment = { horizontal: "center" };

// Freeze pane
      worksheet.views = [{ state: "frozen", ySplit: 3 }];


      // Enable filtering
      worksheet.autoFilter = {
        from: { row: 3, column: 1 },
        to: { row: 3, column: colCount },
      };

      /* ----------------------------------------
         5. ADD DATA ROWS (start at row 4+)
         ---------------------------------------- */
      for (const row of rows) {
        const out = {};
        for (const a of accessors) {
          if (!a.key) continue;
          out[a.key] = a.getValue(row) ?? "";
        }
        worksheet.addRow(out);
      }

      /* ----------------------------------------
         6. GENERATE & DOWNLOAD FILE
         ---------------------------------------- */
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const fileName = shortTitle(safeTitle);
      saveAs(blob, `${fileName}_${timestamp()}.xlsx`);

      setToast({
        open: true,
        severity: "success",
        message: "XLSX export completed.",
      });

    } catch (err) {
      console.error("Export XLSX failed:", err);
      setToast({
        open: true,
        severity: "error",
        message: "XLSX export failed.",
      });
    }
  }, [accessors, resolveRowsForExport, pageTitle]);

  /* ------------------------------- PDF ------------------------------- */
  const exportPDF = useCallback(async () => {
    try {
      const rows = await resolveRowsForExport();
      const doc = new jsPDF();

      const safeTitle = pageTitle || "";

      const head = [accessors.filter((a) => a.key).map((a) => a.label)];
      const body = rows.map((row) => accessors.filter((a) => a.key).map((a) => a.getValue(row)));

      autoTable(doc, {
        head,
        body,
        styles: { fontSize: 10 },
        margin: { top: 25 },  // leave space for title
        didDrawPage: function (data) {
          doc.setFontSize(16);
          doc.text(safeTitle, data.settings.margin.left, 15);
        }
      });
      const fileName = shortTitle(safeTitle);

      doc.save(`${fileName}_${timestamp()}.pdf`);

      setToast({ open: true, severity: 'success', message: 'PDF export completed.' });
    } catch (err) {
      console.error('Export PDF failed:', err);
      setToast({ open: true, severity: 'error', message: 'PDF export failed.' });
    }
  }, [accessors, resolveRowsForExport, pageTitle]);

  const handleSelectFormat = useCallback(
      (fmt) => {
        closeMenu();
        if (exporting) return; // prevent double-clicks
        switch (fmt) {
          case 'csv':
            exportCSV();
            break;
          case 'txt':
            exportTXT();
            break;
          case 'xlsx':
            exportXLSX();
            break;
          case 'pdf':
            exportPDF();
            break;
          default:
            break;
        }
      },
      [closeMenu, exporting, exportCSV, exportTXT, exportXLSX, exportPDF],
  );

  return (
      <div>

        <Tooltip title="Export">
        <IconButton aria-label="Export menu" onClick={openMenu} disabled={exporting}>
          <FileDownloadIcon aria-label="Download" />
        </IconButton>
        </Tooltip>

        <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={closeMenu}>

          {enabledFormats?.csv && (
          <MenuItem disabled={exporting} onClick={() => handleSelectFormat('csv')}>
            <ListItemIcon>
              <CsvIcon aria-label="CSV" />
            </ListItemIcon>
            <ListItemText primary="CSV" />
          </MenuItem>
          )}
          {enabledFormats?.txt && (
          <MenuItem disabled={exporting} onClick={() => handleSelectFormat('txt')}>
            <ListItemIcon>
              <TxtIcon aria-label="TXT" />
            </ListItemIcon>
            <ListItemText primary="TXT" />
          </MenuItem>
          )}
          {enabledFormats?.xlsx && (
          <MenuItem disabled={exporting} onClick={() => handleSelectFormat('xlsx')}>
            <ListItemIcon>
              <XlsxIcon aria-label="XLSX" />
            </ListItemIcon>
            <ListItemText primary="XLSX" />
          </MenuItem>
          )}
          {enabledFormats?.pdf && (
          <MenuItem disabled={exporting} onClick={() => handleSelectFormat('pdf')}>
            <ListItemIcon>
              <PdfIcon aria-label="PDF" />
            </ListItemIcon>
            <ListItemText primary="PDF" />
          </MenuItem>
          )}
        </Menu>
        <Snackbar
            open={toast.open}
            autoHideDuration={4000}
            onClose={() => setToast((t) => ({ ...t, open: false }))}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert
              onClose={() => setToast((t) => ({ ...t, open: false }))}
              severity={toast.severity}
              variant="filled"
              sx={{ width: '100%' }}
          >
            {toast.message}
          </Alert>
        </Snackbar>
      </div>
  );
};

ExportOptions.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object).isRequired,
  headers: PropTypes.arrayOf(
      PropTypes.shape({
        label: PropTypes.string,
        field: PropTypes.string,
        key: PropTypes.string,
        fields: PropTypes.arrayOf(PropTypes.string),
        separator: PropTypes.string,
        suffix: PropTypes.string,
        dateFormat: PropTypes.string,
      }),
  ).isRequired,
  /** Provide this for server-side pagination. Should return Promise<Array<object>>. */
  fetchAllRows: PropTypes.func,
  pageTitle: PropTypes.string,
  exportOptions: PropTypes.shape({
    csv: PropTypes.bool,
    txt: PropTypes.bool,
    xlsx: PropTypes.bool,
    pdf: PropTypes.bool,
  })
};

ExportOptions.defaultProps = {
  fetchAllRows: null,
  exportOptions: { csv: true, txt: true, xlsx: true, pdf: true },
};

export default ExportOptions;