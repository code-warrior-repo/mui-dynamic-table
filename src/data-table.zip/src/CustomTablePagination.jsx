import React from 'react';
import { IconButton, Typography, Stack } from '@mui/material';
import { FirstPage, LastPage, ChevronLeft, ChevronRight } from '@mui/icons-material';

export default function CustomTablePagination({
                                                  count,
                                                  page,
                                                  rowsPerPage,
                                                  onPageChange,
                                                  onRowsPerPageChange,
                                                  rowsPerPageOptions = [10, 20, 30, { value: -1, label: 'All' }]
                                              }) {
    const totalPages = rowsPerPage === -1 ? 1 : Math.ceil(count / rowsPerPage);

    const handleFirstPage = () => onPageChange(0);
    const handlePrevPage = () => onPageChange(page - 1);
    const handleNextPage = () => onPageChange(page + 1);
    const handleLastPage = () => onPageChange(totalPages - 1);

    const renderPageNumbers = () => {
        const pageNumbers = [];
        if (totalPages <= 5) {
            for (let i = 1; i <= totalPages; i++) pageNumbers.push(i);
        } else {
            if (page > 2) pageNumbers.push(1, '...');
            for (let i = Math.max(1, page - 1); i <= Math.min(totalPages, page + 3); i++) {
                pageNumbers.push(i);
            }
            if (page < totalPages - 3) pageNumbers.push('...', totalPages);
        }
        return pageNumbers.map((num, idx) => (
            <IconButton
                key={idx}
                onClick={() => typeof num === 'number' && onPageChange(num - 1)}
                disabled={num === '...'}
                color={num === page + 1 ? 'primary' : 'default'}
                sx={{ fontSize: '16px' }}
            >
                {num}
            </IconButton>
        ));
    };

    const from = page * rowsPerPage + 1;
    const to = rowsPerPage === -1 ? count : Math.min(count, (page + 1) * rowsPerPage);

    return (
        <Stack direction="row" spacing={2} sx={{ justifyContent: "flex-end", alignItems: "center", p: 2, border: '1px solid #ccc'}}>
            {/* Rows per page selector */}
            <Stack  direction="row" spacing={1}>
                <Typography
                    sx={{
                        fontSize: '0.875rem',
                        fontWeight: 400,
                        color: 'text.primary',
                        fontFamily: 'Roboto, Arial, sans-serif'
                    }}
                >
                    Rows per page:
                </Typography>
                <select
                    value={rowsPerPage}
                    onChange={onRowsPerPageChange}
                    aria-label="Rows per page"
                    style={{
                        fontSize: '0.875rem',
                        fontFamily: 'Roboto, Arial, sans-serif',
                        color: '#000',
                        backgroundColor: '#fff',
                        border: '1px solid rgba(0,0,0,0.23)',
                        borderRadius: '4px',
                        padding: '6px 8px',
                        minWidth: '80px'
                    }}
                >
                    {(rowsPerPageOptions || []).map((opt, index) =>
                        opt && typeof opt === 'object' ? (
                            <option key={`object-${opt.value}-${index}`} value={opt.value}>
                                {opt.label}
                            </option>
                        ) : (
                            <option key={`value-${opt}-${index}`} value={opt}>
                                {opt}
                            </option>
                        )
                    )}
                </select>
            </Stack>
            {/* Displayed rows info */}
            <Typography
                sx={{
                    fontSize: '0.875rem',
                    fontWeight: 400,
                    color: 'text.primary',
                    fontFamily: 'Roboto, Arial, sans-serif'
                }}
            >
                {`${from}-${to} of ${count !== -1 ? count : `more than ${to}`}`}
            </Typography>

            {/* Pagination controls */}
            <Stack direction="row" spacing={0} sx={{ justifyContent: "flex-end", alignItems: "center",}}>
                <IconButton onClick={handleFirstPage} disabled={page === 0} aria-label="First page">
                    <FirstPage />
                </IconButton>
                <IconButton onClick={handlePrevPage} disabled={page === 0} aria-label="Previous page">
                    <ChevronLeft />
                </IconButton>
                {renderPageNumbers()}
                <IconButton
                    onClick={handleNextPage}
                    disabled={page >= totalPages - 1}
                    aria-label="Next page"
                >
                    <ChevronRight />
                </IconButton>
                <IconButton
                    onClick={handleLastPage}
                    disabled={page >= totalPages - 1}
                    aria-label="Last page"
                >
                    <LastPage />
                </IconButton>
            </Stack>
        </Stack>
    );
}