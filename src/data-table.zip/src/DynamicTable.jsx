import React, {useCallback, useEffect, useRef, useState} from 'react';
import {
    Box,
    Button,
    Checkbox, FormControlLabel,
    IconButton,
    Paper,
    Stack,
    Table,
    TableBody,
    TableContainer,
    TableHead,
    TableSortLabel,
    Tooltip,
    Typography
} from '@mui/material';
import {ThemeProvider} from '@mui/material/styles';
import PropTypes from 'prop-types';
import InfoIcon from '@mui/icons-material/Info';
import Search from './Search';
import ExportOptions from './ExportOptions';
import MultiColumnSort from './MultiColumnSort';
import ThemeSelector from './ThemeSelector';
import DensityMediumIcon from '@mui/icons-material/DensityMedium';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import FullscreenExitIcon from '@mui/icons-material/FullscreenExit';
import {themes} from './themes';
import {StyledActionTableCell, StyledTableCell, StyledTableRow} from './StyledComponents';
import CustomTablePagination from './CustomTablePagination';
import {getByPath, sortData, toDisplayString} from "./util";
import ViewIcon from '@mui/icons-material/Visibility';
import EditIcon from '@mui/icons-material/Edit';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import DeleteIcon from '@mui/icons-material/Delete';
import ReportIcon from '@mui/icons-material/Report';
import PersonRemoveAlt1Icon from '@mui/icons-material/PersonRemoveAlt1';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import EmailIcon from '@mui/icons-material/Email';
import { visuallyHidden } from '@mui/utils';

/* NOSONAR */
const DynamicTable = ({
                          headers,
                          data = [],
                          totalCount = undefined,
                          currentPage = 0,
                          serverSidePagination = false,
                          onPageChangeRequest = null,
                          fetchAllForExport = null,
                          tooltipFields = [],
                          showActionIcons = false,
                          enableView = false,
                          enableEdit = false,
                          enableDelete = false,
                          enableClone = false,
                          enableReportLink,
                          onView,
                          onEdit,
                          onDelete,
                          editLabel = 'Edit',
                          deleteLabel = 'Delete',
                          onClone,
                          onReportLink,
                          actionVisibilityRules = {},
                          initialRowsPerPage = 5,
                          orderBy = '',
                          order = 'asc',
                          searchByText = false,
                          enableExport = false,
                          exportOptions = {},
                          pageTitle = '',
                          enableMultiColumnSort = false,
                          enableThemes = false,
                          enableDensePadding = false,
                          enableFullScreenOption = false,
                          emptyDataMessage = 'The information entered does not match our records, please verify the information and try again.',
                          enableEmail = false,
                          onEmail,
                          uniqueField = '',

                      }) => { // NOSONAR

    const [sortColumn, setSortColumn] = useState(orderBy || '');
    const [sortDirection, setSortDirection] = useState(order || 'asc');
    const [page, setPage] = useState(currentPage);
    const [rowsPerPage, setRowsPerPage] = useState(initialRowsPerPage);
    const [searchText, setSearchText] = useState('');
    const [columnWidths, setColumnWidths] = useState({});
    const [selectedColumns, setSelectedColumns] = useState([]);
    const [currentTheme, setCurrentTheme] = useState('default');
    const [densePadding, setDensePadding] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);

    const tableRef = useRef(null);
    const hasActions = enableView || enableEdit || enableDelete || enableClone || enableReportLink;
    const [selectedEmailRows, setSelectedEmailRows] = useState([]);
    const handleEmailClick = () => {
        const rowsToSend =
            selectedEmailRows.length > 0
                ? filteredData.filter(row => selectedEmailRows.includes(row[uniqueField]))
                : filteredData;
        if (onEmail) {
            onEmail(rowsToSend);
        }
    };

    const canShowAction = (actionName, row) => {
        if (!actionVisibilityRules[actionName]) return true; // default: show
        return actionVisibilityRules[actionName](row);
    };
    const actionIconSx = {
        textTransform: 'none',
        minWidth: 0,
        px: 0.75,

        '&:hover': {
            backgroundColor: 'primary.main',
            borderColor: 'primary.main',
            color: 'primary.contrastText',
        },

        '&:focus-visible': {
            backgroundColor: 'primary.dark',
            borderColor: 'primary.dark',
            color: 'primary.contrastText',
            outline: 'none',
        },
    };
    const actionButtonSx = {
        textTransform: 'none',
        minWidth: 0,
        px: 0.75,
        py: 0.25,
        lineHeight: 1.2,

        '&:hover': {
            backgroundColor: 'primary.main',
            borderColor: 'primary.main',
            color: 'primary.contrastText',
        },

        '&:focus-visible': {
            backgroundColor: 'primary.dark',
            borderColor: 'primary.dark',
            color: 'primary.contrastText',
            outline: 'none',
        },
    };
    useEffect(() => {
        const handleFullscreenChange = () => {
            setIsFullscreen(!!document.fullscreenElement);
        };

        document.addEventListener('fullscreenchange', handleFullscreenChange);
        return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
    }, []);


    const setTableNode = useCallback((node) => {
        if (!node) return;       // handle unmount
        tableRef.current = node;
        const widths = {};
        headers.forEach((h) => {
            if (h?.field) {
                widths[h.field] = h?.width ?? 'auto';
            }
        });
        setColumnWidths(widths);
    }, [headers]);

    const handleRequestSort = (property) => {
        const isSame = sortColumn === property;
        const newOrder = isSame && sortDirection === "asc" ? "desc" : "asc";

        // update LOCAL state for client sorting
        setSortColumn(property);
        setSortDirection(newOrder);

        // server-side only triggers backend call
        if (serverSidePagination && onPageChangeRequest) {
            onPageChangeRequest({
                page,
                rowsPerPage,
                sortBy: property,
                sortDir: newOrder
            });
        }
    };

   /* const handleRequestSort = (property) => {
        const isSame = orderBy === property;
        const newOrder = isSame && order === "asc" ? "desc" : "asc";

        onPageChangeRequest({
            page,
            rowsPerPage,
            sortBy: property,
            sortDir: newOrder
        });
    };*/

    const handleChangePage = (newPage) => {
        setPage(newPage);

        if (serverSidePagination && onPageChangeRequest) {
            onPageChangeRequest({
                page: newPage,
                rowsPerPage,
                sortBy: orderBy,
                sortDir: order
            });
        }
    };

    const handleChangeRowsPerPage = (event) => {
        const value = event.target.value;
        const nextRowsPerPage =
            value === "All"
                ? -1            // show all rows
                : Number.parseInt(value, 10);
        setRowsPerPage(nextRowsPerPage);
        setPage(0);
        console.log('rowsPerPage', nextRowsPerPage);
        if (serverSidePagination && onPageChangeRequest) {
            onPageChangeRequest({
                page: 0,
                rowsPerPage: nextRowsPerPage,
                sortBy: orderBy,
                sortDir: order
            });
        }
    };

    const handleSearchTextChange = (event) => {
        setSearchText(event.target.value);
        setPage(0);
    };

    const handleSortChange = (newSelectedColumns) => {
        setSelectedColumns(newSelectedColumns);
    };

    const handleThemeChange = (theme) => {
        setCurrentTheme(theme);
    };

    const handleToggleDensePadding = () => {
        setDensePadding(!densePadding);
    };

    const handleToggleFullscreen = () => {
        if (!document.fullscreenElement) {
            tableRef.current?.requestFullscreen();
        } else {
            document.exitFullscreen();
        }
        setIsFullscreen(!isFullscreen);
    };

    const normalizedSearch = String(searchText || '').trim().toLowerCase();

    function toSearchableString(value) {
        if (value == null) return '';
        if (typeof value === 'string') return value;
        if (typeof value === 'number' || typeof value === 'boolean') return String(value);
        if (value instanceof Date) return value.toISOString();
        if (Array.isArray(value)) return value.map(v => toSearchableString(v)).join(' ');
        return JSON.stringify(value);
    }

    const filteredData = data && data.length > 0 && data.filter(function (row) {
        return headers.some(function (header) {
            const value = getByPath(row, header.field);
            const text = toSearchableString(value).toLowerCase();
            return text.includes(normalizedSearch);
        });
    });


    const sortedData = serverSidePagination
        ? filteredData
        : sortData(filteredData, {
            selectedColumns,
            orderBy: sortColumn,
            order: sortDirection
        });

    const sliceOrEmpty = (arr) =>
        Array.isArray(arr)
            ? arr.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
            : [];

    const paginatedData = serverSidePagination
        ? sortedData
        : sliceOrEmpty(sortedData);
    const displayedCount = serverSidePagination ? (totalCount ?? data.length) : filteredData.length;
    const shouldFetchBackend = serverSidePagination && totalCount > filteredData.length;
    const toggleEmailRow = (checked, id, setSelectedEmailRows) => {
        if (checked) {
            setSelectedEmailRows(prev => [...prev, id]);
        } else {
            setSelectedEmailRows(prev => prev.filter(x => x !== id));
        }
    };

    const toggleSelectAllEmail = (checked, filteredData, uniqueField, setSelectedEmailRows) => {
        if (checked) {
            setSelectedEmailRows(filteredData.map(r => r[uniqueField]));
        } else {
            setSelectedEmailRows([]);
        }
    };
    const emailCheckboxStyle = {
        color: '#FFF',
        '&.Mui-checked': { color: '#FFF' },
        '&.MuiCheckbox-indeterminate': { color: '#FFF' },
        '&:hover': {
            backgroundColor: 'transparent',
            color: '#FFF',
        },
        '&.Mui-disabled': {
            color: 'rgba(255,255,255,0.4)',
        },
        '&.Mui-focusVisible': { color: '#FFF' },
        '& .MuiSvgIcon-root': { fill: '#FFF' },
    };

    return (
        <ThemeProvider theme={themes[currentTheme]}>
            <TableContainer component={Paper} ref={tableRef}>
                <Stack direction="row" spacing={1} sx={{justifyContent: "flex-end", alignItems: "center",}}>
                    {searchByText && (
                        <Search searchText={searchText} handleSearchTextChange={handleSearchTextChange}/>
                    )}
                    {enableDensePadding && (
                        <IconButton onClick={handleToggleDensePadding} aria-label="Dense Padding">
                            <Tooltip title="Dense padding"><DensityMediumIcon/></Tooltip>
                        </IconButton>
                    )}
                    {enableMultiColumnSort && (
                        <MultiColumnSort headers={headers} selectedColumns={selectedColumns}
                                         handleSortChange={handleSortChange}/>
                    )}
                    {enableExport && (

                        <ExportOptions
                            headers={headers}
                            data={shouldFetchBackend ? [] : filteredData}
                            pageTitle={pageTitle}   // <-- pass page title
                            fetchAllRows={
                                shouldFetchBackend
                                    ? () =>
                                        fetchAllForExport({
                                            orderBy,
                                            order,
                                            selectedColumns,
                                        })
                                    : null
                            }
                            exportOptions={exportOptions}
                        />

                    )}
                    {enableThemes && (
                        <ThemeSelector currentTheme={currentTheme} handleThemeChange={handleThemeChange}/>
                    )}
                    {enableFullScreenOption && (
                        <IconButton aria-label={"fullscreen"} onClick={handleToggleFullscreen}>
                            <Tooltip title="Toggle fullscreen">{isFullscreen ? <FullscreenExitIcon/> :
                                <FullscreenIcon/>}</Tooltip>
                        </IconButton>
                    )}
                    {enableEmail && (
                        <Tooltip title="Send Email">
                            <IconButton onClick={handleEmailClick}>
                                <EmailIcon/>
                            </IconButton>
                        </Tooltip>
                    )}
                </Stack>

                <Table size={densePadding ? 'small' : 'medium'} sx={{minWidth: 500}} aria-label="dynamic table"
                       ref={setTableNode}>
                    <TableHead>
                        <StyledTableRow>
                            {headers.map(header => (
                                <StyledTableCell key={header.field}>
                                    <TableSortLabel
                                        active={sortColumn === header.field}
                                        direction={sortColumn === header.field ? sortDirection : 'asc'}
                                        onClick={() => handleRequestSort(header.field)}
                                    >
                                        <strong>{header.label}</strong>
                                        {orderBy === header.field ? (
                                            <Box component="span" sx={visuallyHidden}>
                                                {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                                            </Box>
                                        ) : null}
                                    </TableSortLabel>
                                    {tooltipFields[header.field] && (
                                        <Tooltip
                                            title={
                                                <div>
                                                    <ul style={{margin: 0, paddingLeft: '20px'}}>
                                                        {tooltipFields[header.field].map(item => (
                                                            <li key={item}>{item}</li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            }
                                            arrow
                                        >
                                            <IconButton size="small" aria-label="Info">
                                                <InfoIcon fontSize="small"/>
                                            </IconButton>
                                        </Tooltip>
                                    )}
                                </StyledTableCell>
                            ))}
                            {hasActions && <StyledTableCell><strong>Action(s)</strong></StyledTableCell>}
                            {enableEmail && (
                                <StyledTableCell>
                                    <FormControlLabel
                                        label={<strong>Email</strong>}
                                        labelPlacement="end"
                                        control={
                                            <Tooltip title="Select All">
                                                <Checkbox
                                                    aria-label="Select All Emails"
                                                    data-testid="dynamic-email-select-all-checkbox"
                                                    checked={
                                                        filteredData.length > 0 &&
                                                        selectedEmailRows.length === filteredData.length
                                                    }
                                                    indeterminate={
                                                        selectedEmailRows.length > 0 &&
                                                        selectedEmailRows.length < filteredData.length
                                                    }
                                                    onChange={(e) =>
                                                        toggleSelectAllEmail(
                                                            e.target.checked,
                                                            filteredData,
                                                            uniqueField,
                                                            setSelectedEmailRows
                                                        )
                                                    }
                                                    sx={emailCheckboxStyle}
                                                />
                                            </Tooltip>
                                        }
                                    />
                                </StyledTableCell>
                            )}
                        </StyledTableRow>
                    </TableHead>

                    <TableBody>
                        {paginatedData.length > 0 ? (
                            paginatedData.map((row, rowIndex) => (
                                <StyledTableRow key={JSON.stringify(rowIndex)}>
                                    {headers.map(header => (
                                        <StyledTableCell key={header.field} style={{width: columnWidths[header.field]}}>
                                            {
                                                header.fields
                                                    ? header.fields.map((fieldPath) => toDisplayString(getByPath(row, fieldPath))).join(header.separator || '') + (header.suffix || '')
                                                    : toDisplayString(getByPath(row, header.field), header.dateFormat)
                                            }
                                        </StyledTableCell>
                                    ))}
                                    {enableEmail && (
                                        <StyledTableCell>
                                            <Checkbox
                                                checked={selectedEmailRows.includes(row[uniqueField])}
                                                onChange={(e) => {
                                                    e.stopPropagation();
                                                    const id = row[uniqueField];
                                                    toggleEmailRow(e.target.checked, id, setSelectedEmailRows);
                                                }}
                                                slotProps={{
                                                    input: {
                                                        'aria-label': `label-${row[uniqueField]}`,
                                                        'data-testid': `dynamic-email-checkbox-${row[uniqueField]}`,
                                                    }
                                                }}
                                            />
                                        </StyledTableCell>
                                    )}
                                    {hasActions && (
                                        <StyledActionTableCell>
                                            <Box sx={{display: "flex", width: "100%", justifyContent: "space-between"}}>
                                                    {enableView && canShowAction("view", row) && (
                                                        <Box sx={{width: "33%", display: "flex", justifyContent: "flex-start"}}>
                                                            {showActionIcons ? (
                                                                <Tooltip title="View">
                                                                    <IconButton
                                                                        aria-label="View"
                                                                        data-testid="dynamic-view-button"
                                                                        onClick={() => onView(row)}
                                                                        size="small"
                                                                        sx={actionIconSx}
                                                                    >
                                                                        <ViewIcon fontSize="small"/>
                                                                    </IconButton>
                                                                </Tooltip>
                                                            ) : (
                                                                <Button
                                                                    aria-label="View"
                                                                    onClick={() => onView(row)}
                                                                    size="small"
                                                                    color="primary"               // matches your theme
                                                                    data-testid={`view-btn-${rowIndex}`}
                                                                >
                                                                    View
                                                                </Button>
                                                            )}
                                                        </Box>
                                                    )}
                                                    {enableEdit && canShowAction("edit", row) && (
                                                        <Box sx={{width: "33%", display: "flex", justifyContent: "flex-start"}}>
                                                            {showActionIcons ? (
                                                                <Tooltip title={editLabel || 'Edit'}>
                                                                    <IconButton
                                                                        aria-label={editLabel || 'Edit'}
                                                                        data-testid="dynamic-edit-button"
                                                                        onClick={() => onEdit(row)}
                                                                        size="small"
                                                                        sx={actionIconSx}
                                                                    >
                                                                        {editLabel === 'Add Back' ?
                                                                            <PersonAddAlt1Icon fontSize="small"/>
                                                                            :
                                                                            <EditIcon fontSize="small"/>
                                                                        }
                                                                    </IconButton>
                                                                </Tooltip>
                                                            ) : (
                                                                <Button
                                                                    aria-label={editLabel || 'Edit'}
                                                                    onClick={() => onEdit(row)}
                                                                    size="small"
                                                                    color="primary"
                                                                    data-testid={`edit-btn-${rowIndex}`}
                                                                >
                                                                    {editLabel || 'Edit'}
                                                                </Button>
                                                            )}
                                                        </Box>
                                                    )}
                                                    {enableClone && canShowAction("clone", row) && (
                                                        <Box sx={{width: "33%", display: "flex", justifyContent: "flex-start"}}>
                                                            {showActionIcons ? (
                                                                <Tooltip title="Clone">
                                                                    <IconButton
                                                                        aria-label="Clone"
                                                                        data-testid="dynamic-clone-button"
                                                                        onClick={() => onClone(row)}
                                                                        size="small"
                                                                        sx={actionIconSx}
                                                                    >
                                                                        <ContentCopyIcon fontSize="small"/>
                                                                    </IconButton>
                                                                </Tooltip>
                                                            ) : (
                                                                <Button
                                                                    aria-label="Clone"
                                                                    onClick={() => onClone(row)}
                                                                    size="small"
                                                                    color="primary"
                                                                    data-testid={`clone-btn-${rowIndex}`}
                                                                >
                                                                    Clone
                                                                </Button>
                                                            )}
                                                        </Box>
                                                    )}
                                                    {enableDelete && canShowAction("delete", row) && (
                                                        <Box sx={{width: "33%", display: "flex", justifyContent: "flex-start"}}>
                                                            {showActionIcons ? (
                                                                <Tooltip title={deleteLabel || 'Delete'}>
                                                                    <IconButton
                                                                        aria-label={deleteLabel || 'Delete'}
                                                                        data-testid="dynamic-delete-button"
                                                                        onClick={() => onDelete(row)}
                                                                        size="small"
                                                                        sx={actionIconSx}
                                                                    >
                                                                        {deleteLabel === 'Remove' ?
                                                                            <PersonRemoveAlt1Icon fontSize="small"/>
                                                                            :
                                                                            <DeleteIcon fontSize="small"/>
                                                                        }
                                                                    </IconButton>
                                                                </Tooltip>
                                                            ) : (
                                                                <Button
                                                                    aria-label={deleteLabel || 'Delete'}
                                                                    onClick={() => onDelete(row)}
                                                                    size="small"
                                                                    color="error"
                                                                    data-testid={`delete-btn-${rowIndex}`}
                                                                >
                                                                    {deleteLabel || 'Delete'}
                                                                </Button>
                                                            )}
                                                        </Box>
                                                    )}
                                                    {enableReportLink && canShowAction("report", row) && (
                                                        <Box sx={{width: "33%", display: "flex", justifyContent: "flex-start"}}>
                                                            {showActionIcons ? (
                                                                <Tooltip title="Report">
                                                                    <IconButton
                                                                        aria-label="Report"
                                                                        data-testid="dynamic-report-link-button"
                                                                        onClick={() => onReportLink(row)}
                                                                        size="small"
                                                                        sx={actionIconSx}
                                                                    >
                                                                        <ReportIcon fontSize="small"/>
                                                                    </IconButton></Tooltip>
                                                            ) : (
                                                                <Button
                                                                    aria-label="Report"
                                                                    onClick={() => onReportLink(row)}
                                                                    size="small"
                                                                    color="primary"
                                                                    sx={actionButtonSx}
                                                                    data-testid={`report-btn-${rowIndex}`}
                                                                >
                                                                    Report
                                                                </Button>
                                                            )}
                                                        </Box>
                                                    )}
                                            </Box>
                                        </StyledActionTableCell>
                                    )}
                                </StyledTableRow>
                            ))
                        ) : (
                            <StyledTableRow>
                                <StyledTableCell colSpan={headers.length + (hasActions ? 3 : 0)} align="center">
                                    <Typography variant="body1">{emptyDataMessage}</Typography>
                                </StyledTableCell>
                            </StyledTableRow>
                        )}

                    </TableBody>
                </Table>

                {(serverSidePagination ? displayedCount > 0 : data.length > initialRowsPerPage) && (
                    <CustomTablePagination
                        count={displayedCount}
                        rowsPerPage={rowsPerPage}
                        page={page}
                        onPageChange={handleChangePage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                        initialRowsPerPage={initialRowsPerPage}
                        rowsPerPageOptions={[10, 20, 30, {value: totalCount || -1, label: 'All'}]}
                    />
                )}
            </TableContainer>
        </ThemeProvider>
    );
};
// Example headers configuration
// noinspection JSUnusedLocalSymbols
/*
const exampleHeaders = [
    {field: 'name', label: 'Name', fields: ['firstName', 'lastName'], separator: ' ', suffix: '', width: 200},
    {field: 'status', label: 'Status', fields: ['status', 'count'], separator: '(', suffix: ')'},
    {field: 'statusBracket', label: 'Status Bracket', fields: ['status', 'count'], separator: '[', suffix: ']'},
    {field: 'statusDash', label: 'Status Dash', fields: ['status', 'count'], separator: '-', suffix: ''},
    {field: 'statusSemicolon', label: 'Status Semicolon', fields: ['status', 'count'], separator: ';', suffix: ''},
    {field: 'statusColon', label: 'Status Colon', fields: ['status', 'count'], separator: ':', suffix: ''},
];
*/

DynamicTable.propTypes = {
    headers: PropTypes.arrayOf(PropTypes.shape({
        label: PropTypes.string.isRequired,
        field: PropTypes.string,
        fields: PropTypes.arrayOf(PropTypes.string),
        separator: PropTypes.string,
        suffix: PropTypes.string,
        width: PropTypes.number,
        dateFormat: PropTypes.string,
    })).isRequired,
    data: PropTypes.arrayOf(PropTypes.object),
    totalCount: PropTypes.number,
    currentPage: PropTypes.number,
    serverSidePagination: PropTypes.bool,
    onPageChangeRequest: PropTypes.func,
    fetchAllForExport: PropTypes.func,
    tooltipFields: PropTypes.objectOf(PropTypes.arrayOf(PropTypes.string)),
    showActionIcons: PropTypes.bool,
    enableView: PropTypes.bool,
    enableEdit: PropTypes.bool,
    enableDelete: PropTypes.bool,
    enableClone: PropTypes.bool,
    enableReportLink: PropTypes.bool,
    onView: PropTypes.any,
    onEdit: PropTypes.any,
    onDelete: PropTypes.any,
    editLabel: PropTypes.string,
    onClone: PropTypes.any,
    onReportLink: PropTypes.any,
    actionVisibilityRules: PropTypes.object,
    initialRowsPerPage: PropTypes.number,
    orderBy: PropTypes.string,
    order: PropTypes.oneOf(['asc', 'desc']),
    searchByText: PropTypes.bool,
    enableExport: PropTypes.bool,
    exportOptions: PropTypes.shape({
        csv: PropTypes.bool,
        txt: PropTypes.bool,
        xlsx: PropTypes.bool,
        pdf: PropTypes.bool,
    }),
    enableMultiColumnSort: PropTypes.bool,
    enableThemes: PropTypes.bool,
    enableDensePadding: PropTypes.bool,
    enableFullScreenOption: PropTypes.bool,
    emptyDataMessage: PropTypes.string,
    pageTitle: PropTypes.string,
    enableEmail: PropTypes.bool,
    deleteLabel: PropTypes.string,
    onEmail: PropTypes.any,
    uniqueField: PropTypes.string,
};

export default DynamicTable;