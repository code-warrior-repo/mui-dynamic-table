import React from 'react';
import { TablePagination } from '@mui/material';
import PropTypes from 'prop-types';

const Pagination = ({ count, rowsPerPage, page, onPageChange, onRowsPerPageChange, initialRowsPerPage }) => (
  <TablePagination
    rowsPerPageOptions={[initialRowsPerPage, initialRowsPerPage * 2, initialRowsPerPage * 3, {value: -1, label: 'All'}]}
    component="div"
    count={count}
    rowsPerPage={rowsPerPage}
    page={page}
    onPageChange={onPageChange}
    onRowsPerPageChange={onRowsPerPageChange}
  />
);

Pagination.propTypes = {
  count: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
  page: PropTypes.number.isRequired,
  onPageChange: PropTypes.func.isRequired,
  onRowsPerPageChange: PropTypes.func.isRequired,
  initialRowsPerPage: PropTypes.number.isRequired,
};

export default Pagination;