'use client';
import {DynamicTable} from '@company/mui-data-table';

export default function Page() {
    const mockData = [
            {
                "firstName": "Alice",
                "lastName": "Johnson",
                "status": "Active",
                "count": 5
            },
            {
                "firstName": "Bob",
                "lastName": "Williams",
                "status": "Inactive",
                "count": 2
            },
            {
                "firstName": "Charlie",
                "lastName": "Brown",
                "status": "Pending",
                "count": 7
            },
            {
                "firstName": "Diana",
                "lastName": "Smith",
                "status": "Active",
                "count": 3
            }
    ];
    const mockHeaders = [
        {field: 'name', label: 'Name', fields: ['firstName', 'lastName'], separator: ' ', suffix: '', width: 200},
        {field: 'status', label: 'Status', fields: ['status', 'count'], separator: '(', suffix: ')'},
        {field: 'statusBracket', label: 'Status Bracket', fields: ['status', 'count'], separator: '[', suffix: ']'},
        {field: 'statusDash', label: 'Status Dash', fields: ['status', 'count'], separator: '-', suffix: ''},
        {field: 'statusSemicolon', label: 'Status Semicolon', fields: ['status', 'count'], separator: ';', suffix: ''},
        {field: 'statusColon', label: 'Status Colon', fields: ['status', 'count'], separator: ':', suffix: ''},
    ];

    return <DynamicTable
        headers={mockHeaders} data={mockData} initialRowsPerPage={2}
        enableExport
        enableSearch
        pageTitle="Mui data table demo"
        enableDensePadding
        enableThemes
    />;
}